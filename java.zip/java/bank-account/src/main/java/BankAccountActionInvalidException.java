class BankAccountActionInvalidException extends Exception {

    BankAccountActionInvalidException(String message) {
        super(message);
    }
}
