class Greeter {

    String getGreeting() {
        return "Hello World!";
    }

}
