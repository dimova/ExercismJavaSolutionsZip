enum Orientation {

    NORTH, EAST, SOUTH, WEST

}
