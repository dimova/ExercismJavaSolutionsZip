class ValueNotFoundException extends Exception {

    ValueNotFoundException(String message) {
        super(message);
    }
}
