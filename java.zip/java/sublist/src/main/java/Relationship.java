enum Relationship {

    EQUAL, SUBLIST, SUPERLIST, UNEQUAL

}
