class ChainNotFoundException extends Exception {
    public ChainNotFoundException(String message) {
        super(message);
    }
}
