import java.util.GregorianCalendar;

class Leap {
    GregorianCalendar greg = new GregorianCalendar();
    boolean isLeapYear(int year) {
        return greg.isLeapYear(year);
    }

}
