class BufferIOException extends Exception {

    BufferIOException(String message) {
        super(message);
    }
}
