public class TriangleException extends Exception {
	public TriangleException(String s) {
		super(s);
	}
}
